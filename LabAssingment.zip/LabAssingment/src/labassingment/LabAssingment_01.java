
import java.util.Arrays;
public class LabAssingment_01 {
    public static void main(String args[]) {
        int index, size;
        int array[] = {10, 20, 25, 63, 96, 57, 100, 78, 89, 69};
        size = array.length;
        for (int i = 0; i < size; i++) {
            for (int j = i + 1; j < size; j++) {
                if (array[i] > array[j]) {
                    index = array[i];
                    array[i] = array[j];
                    array[j] = index;
                }
            }
        }
        Arrays.sort(array);
        System.out.println("Sorted array is :" + Arrays.toString(array));
        System.out.println("The largest number in array is:: " + array[size - 1]);
    }
}