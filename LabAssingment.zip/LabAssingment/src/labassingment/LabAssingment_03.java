package labassingment;
import java.util.Arrays;
import java.util.Scanner;

class BubbleSort{
  public static void main(String []args) {
    int num, i, j, temp;
    Scanner input = new Scanner(System.in);
 
    System.out.println("Enter the number of integers to sort:");
    num = input.nextInt();
 
    int array[] = new int[num];
 
    System.out.println("Enter " + num + " integers: ");
 
    for (i = 0; i < num; i++) 
      array[i] = input.nextInt();
 
    for (i = 0; i < ( num - 1 ); i++) {
      for (j = 0; j < num - i - 1; j++) {
        if (array[j] > array[j+1]) 
        {
           temp = array[j];
           array[j] = array[j+1];
           array[j+1] = temp;
        }
      }
    }
    System.out.println("Sorted list of integers:");
 
    for (i = 0; i < num; i++) 
      System.out.println(array[i]);
  }
}




















//class Main {
//
//  // perform the bubble sort
//  static void bubbleSort(int array[]) {
//    int size = array.length;
//    // loop to access each array element
//    for (int i = 0; i < size - 1; i++)    
//      // loop to compare array elements
//      for (int j = 0; j < size - i - 1; j++)
//
//        // compare two adjacent elements
//        // change > to < to sort in descending order
//        if (array[j] > array[j + 1]) {
//
//          // swapping occurs if elements
//          // are not in the intended order
//          int temp = array[j];
//          array[j] = array[j + 1];
//          array[j + 1] = temp;
//        }
//  }
//  public static void main(String args[]) {
//      
//    int[] data = { -2, 45, 0, 11, -9 };
//    
//    // call method using class name
//    Main.bubbleSort(data);
//    System.out.println("Sorted Array in Ascending Order:");
//    System.out.println(Arrays.toString(data));
//  }
//}